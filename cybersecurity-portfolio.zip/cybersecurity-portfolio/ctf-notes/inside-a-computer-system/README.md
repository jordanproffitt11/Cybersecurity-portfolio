# Inside a Computer System

Notes from TryHackMe's "Inside a Computer System" room — covers CPU, memory, OS fundamentals, and how these relate to security concepts like exploitation and forensics.

## Key concepts

**CPU/architecture notes:**
-

**Memory/OS notes:**
-

**How this connects to security (e.g., exploitation, forensics, malware analysis):**
-

**What I struggled with:**
-
