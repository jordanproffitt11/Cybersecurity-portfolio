# Careers in Cyber

Notes from TryHackMe's Careers in Cyber content — useful for shaping my own job search strategy and understanding how different roles (SOC analyst, pentester, GRC, etc.) differ.

## Key takeaways

**Roles explored:**
-

**Role I'm targeting and why:**
-

**Skills/certs that map to that role:**
-

**Notes:**
-
