# Introduction to Defensive Security

Notes and write-ups from TryHackMe's Defensive Security introductory content.

## Room: [Room Name]

**Date completed:**

**Summary:**
What was the scenario or objective of this room?

**Tools/techniques used:**
-

**What I learned:**
-

**What I struggled with:**
-

---

<!-- Copy the block above for each new room -->
