# Cybersecurity Portfolio

Notes, write-ups, and hands-on projects documenting my path toward a cybersecurity analyst role. Built alongside CompTIA Security+ study and TryHackMe/LetsDefend practice.

## Structure

- `/ctf-notes/` — Room and challenge write-ups from TryHackMe, organized by topic
- `/home-lab/` — Documentation from my SIEM/detection home lab project (Splunk + Sysmon)
- `/detection-rules/` — Detection logic, Sysmon configs, and Splunk searches I've built

## Current Focus

- Completing TryHackMe's Pre Security and SOC Level 1 paths
- Studying for CompTIA Security+
- Building a cloud-based SIEM lab (Splunk + Sysmon) for hands-on detection engineering practice

## Certifications

- [List your completed certs here]
- CompTIA Security+ — in progress
